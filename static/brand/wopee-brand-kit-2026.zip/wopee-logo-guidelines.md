# Wopee.io logo guidelines (v1.1, 3 Nov 2026)

The system is "One W, two tiers". The W is the first letter of the name, and the yellow square around it goes on or off with the background. The monkey is the character on people channels. In this kit, the logos are in [logos/](logos/), the icon sets in [favicons/](favicons/), the avatars in [avatars/](avatars/) and the monkey in [mascot/](mascot/).

---

## 0. One-page summary

| Question           | Answer                                                                                                                                                                                                                                  |
| ------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| What is the logo?  | The **Bungee "W"** followed by **"opee.io" in Rubik ExtraBold (800)**, both outlined. Together they read "Wopee.io". On light, purple and yellow grounds the W sits in a square. On dark grounds the square is off and the W is yellow. |
| The only accent    | The **dot of ".io"**: purple on white and yellow grounds, yellow on ink and purple grounds.                                                                                                                                             |
| Who is the monkey? | The **mascot**, the tier 2 character: the original 2023 monkey (W cap, sunglasses, headphones), the face on YouTube, LinkedIn, events and the email sign-off. It is **not** the logo (section 10).                                      |
| Default file       | [`wopee-logo-horizontal-color-light.svg`](logos/svg/wopee-logo-horizontal-color-light.svg)                                                                                                                                              |
| Smallest symbol    | 16 px (the hand-tuned favicon cut); 24 px for the full symbol                                                                                                                                                                           |
| Smallest lockup    | 80 px wide on screen, 20 mm in print                                                                                                                                                                                                    |
| Clear space        | 1 **x** on every side, where x = the height of the "o" in "opee.io"                                                                                                                                                                     |
| Colours            | Yellow `#ffcc00`, purple `#7030a0`, ink `#111827`, white `#ffffff`, purple-300 `#b98ae0` for Commander on dark only, and pure black `#000000` for one-colour print only                                                                 |
| Never              | Write "W Wopee.io" · stack the W above the full "Wopee.io" · put the monkey in place of the logo · use purple #7030a0 on dark · use yellow text on white · add red or cyan · lock a tagline into the logo                               |

---

## 1. Name

- Written name: **Wopee.io**, with a capital W and the lowercase ".io" always included. Never write "Wopee", "WOPEE", "wopee.io" (except in URLs and code) or "Wopee IO".
- Caps ("WOPEE.IO") are allowed only inside caps-only label systems, such as the Build & Break badge ring. Never use them in the corporate lockup.
- In code and package names, use lowercase: `wopee-mcp`, `@wopee/...`.
- Alt text: `alt="Wopee.io"`. For a sub-brand, use `alt="Wopee.io Commander"` or `alt="Wopee.io MCP"`. A decorative mascot gets `alt=""`. Every master SVG carries `role="img"`, `aria-label` and a `<title>`.
- Legal name on formal documents: "wopee labs s.r.o.", next to the L1 lockup.

## 2. Anatomy

```
 788 ┌──────┐                          <- square top (W cap + 88)
 743 │      │            ▄▄           <- i-dot top
 700 │ ████ │                          <- W height in the square = Rubik cap height
 520 │ █  █ │ opee.io                  <- Rubik x-height
   0 │ ████ │ ─────────────           <- shared baseline: the W in the square stands on it
 -88 └──────┘                          <- square bottom (88 below the baseline, as 88 above the W)
-190          p                        <- descender
      [  W  ] gap 60 [ opee.io ]
```

All values are font units on a shared em of 1000, the same size relation as the 2024 artwork.

- **The W is the first letter.** It sits directly before "opee.io", so the pair reads "Wopee.io". **Never** place the W or its square before the full word "Wopee.io", which reads "W Wopee.io", and never above it.
- **One glyph, three outfits.** The same Bungee W outline is the letter in the wordmark (square off), the block letter in the lockup (square on) and the symbol (square on, alone). It is never redrawn, never swapped for another font's W, and never set as live text in a logo.
- **Shared baseline.** The bare W (cap 720) and "opee.io" (Rubik cap 700, x-height 520) sit on one baseline at the same em size.
- **The W in the square is the capital.** Inside the square the W is Rubik cap height tall (700 units) and stands on the text baseline, so it reads as the capital of "Wopee", level with the feet of "opee.io". The square is centred on that W with 88 units above and below (−88 to 788, side 876, the W at 80 % of the side), and is not lifted or dropped. Its corner radius is 22 % of the side, concentric with the W's own corners. The standalone symbol and the app icons have no baseline to sit on: there the W is 67.7 % of the side and lifted 1 % of the side, because Bungee's W carries its mass low (centroid at 346 of 720).
- **Spacing:**
  - square to "o": ink gap 60;
  - bare W to "o": ink gap 58 (the W's foot tapers away from the "o");
  - "opee.io" tracking −10, e·. −8, .·i −18;
  - everything else is Rubik's default spacing, which is what the 2024 artwork uses.
- **The square rule:**
  - **ON** for light, purple and yellow grounds (an ink square with a yellow W on yellow), and always for the symbol on its own.
  - **OFF** on dark grounds (the W turns yellow), below 24 px lockup height, next to partner logos and in fine one-colour work (embroidery, etching).
- **The dot accent:** the period of ".io" is the only accent. It is purple on white and yellow grounds, and yellow on ink and purple grounds. In Commander it follows the product accent (purple on light, purple-300 on dark). Never split the colour anywhere else, and never before the "p".

## 3. Type

| Role                         | Typeface                                                  | Licence                                        | Where it comes from                                                                                                                |
| ---------------------------- | --------------------------------------------------------- | ---------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| The W (logo)                 | **Bungee** Regular, glyph "W", outlined                   | SIL OFL 1.1, © 2023 The Bungee Project Authors | [google/fonts `ofl/bungee`](https://github.com/google/fonts/tree/main/ofl/bungee), v2.000                                          |
| "opee.io" (logo)             | **Rubik ExtraBold 800**, outlined                         | SIL OFL 1.1, © 2015 The Rubik Project Authors  | [google/fonts `ofl/rubik`](https://github.com/google/fonts/tree/main/ofl/rubik), variable `Rubik[wght].ttf`, instanced at wght 800 |
| Descriptors (COMMANDER, MCP) | Rubik Bold 700 caps, tracking +0.16 em, outlined          | as above                                       | as above                                                                                                                           |
| Build & Break headlines      | Bungee, with a hard offset shadow in yellow-800 `#7a5c00` | as above                                       | as above                                                                                                                           |
| Site, docs and app text      | Rubik (300 to 900)                                        | as above                                       | already the site and docs face                                                                                                     |

- The OFL allows use, outlining and redistribution, including in logos. Keep each `OFL.txt` next to its font file wherever the fonts are shipped. Neither font declares a Reserved Font Name. The logo SVGs contain outlines only, so they need no font at all.
- Bungee is caps-only, so it supplies only the W, never the whole word.

## 4. Lockup set

| #   | Lockup                                                                       | Use                                                                                         | Do not use for                                       | Files                                                                                                  |
| --- | ---------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------- | ---------------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| L1  | **Primary horizontal** (the W in its square + "opee.io"; square off on dark) | Site headers, docs, the email header, deck footers and titles, PDFs: the default everywhere | Spaces under 80 px wide                              | `wopee-logo-horizontal-{color-light,color-dark,on-purple,on-yellow,mono-ink,mono-white}`               |
| L2  | **Stacked**: the original monkey above the in-word wordmark (square off)     | Square spaces: booth walls, merch, video end cards, event badges                            | Navigation bars, formal documents                    | `wopee-logo-stacked-{color-light,color-dark,on-purple,on-yellow}`                                      |
| L3  | **Symbol** (the W in its square)                                             | Favicons, app icons, registry avatars, a collapsed sidebar                                  | Any first contact where the name is not shown nearby | `wopee-symbol-{color-light,on-yellow,mono-ink,mono-white}`, `wopee-symbol-{commander,mcp}-color-light` |
| L4  | **Wordmark** (bare W + "opee.io")                                            | Dark grounds, small sizes, running footers, co-branding strips                              | Replacing L1 where L1 fits on a light ground         | `wopee-wordmark-{color-light,color-dark,on-purple,on-yellow,mono-ink,mono-white}`                      |
| L5  | **Sub-brand** (L1 in the product tile colour + a caps descriptor)            | Product UIs and product pages                                                               | Corporate pages, invoices                            | `wopee-logo-horizontal-{commander,mcp}-{color-light,color-dark}`                                       |
| L6  | **Partner** (L1 + 1 px divider + the partner logo)                           | Co-marketing, "works with Claude Code / Copilot / Cursor"                                   | Implying endorsement without consent                 | built per use, no master                                                                               |

- **Rule of thumb:** use the full lockup wherever it fits, and the symbol only where space forces it or the brand is already on the page.
- **Stacked on dark and purple:** the monkey sits on a yellow disc (section 10). Its cap stays purple, so on purple the disc is required too.
- **No tagline in any logo file.** When a line is needed, set "AI TESTING AGENTS" in the descriptor style next to or under the logo, as text in the layout.

## 5. Sub-brand architecture

Model: **branded house**. Every product is "Wopee.io" plus a descriptor. **The tile colour names the product.** The glyph is never redrawn, and no product gets its own symbol.

| Product                  | Tile (light grounds)                             | On dark (square off)                                                                                                | Descriptor | Descriptor colour   |
| ------------------------ | ------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------- | ---------- | ------------------- |
| Wopee.io (brand, agent)  | yellow `#ffcc00`, ink W                          | yellow W                                                                                                            | none       | n/a                 |
| Commander (cmd.wopee.io) | purple `#7030a0`, yellow W                       | **purple-300 `#b98ae0` W and dot** (never yellow in the app chrome, where it clashes with the amber verdict colour) | COMMANDER  | purple / purple-300 |
| MCP (`wopee-mcp`)        | ink `#111827`, yellow W                          | white W, yellow dot                                                                                                 | MCP        | ink / white         |
| Build & Break (show)     | its own skin (section 5.1), signed with L1 or L4 | n/a                                                                                                                 | n/a        | n/a                 |

- **Placement:** the descriptor is Rubik 700 caps, cap height 150 units (about a fifth of the W), tracking +0.16 em. It is **right-aligned to the end of ".io"**, with its cap top 80 units below the baseline. That keeps it clear of the "p" descender and keeps the lockup compact enough for the 60 px Commander app bar.
- Descriptors are **set in the type system, never drawn**. A new product gets a name, not a new mark.
- In a product UI, the L3 symbol in the product colour followed by the page name is allowed in collapsed sidebars only.

### 5.1 Build & Break

- **Colours:** ink and yellow only, with yellow-800 for the hard shadow. No red.
- **Sticker:** `wopee-sticker-bb-color-dark.svg`: an ink plate with a white die-cut edge, "BUILD / & BREAK" in Bungee yellow with a hard offset shadow, a yellow rule, and the L4 dark wordmark as the signature.
- The sticker may tilt (−4° is the house angle). The corporate lockups never tilt.
- When the show needs a round sticker, use the mascot disc badge [`wopee-mascot-head-color-dark.svg`](mascot/wopee-mascot-head-color-dark.svg) (the original monkey on a yellow disc). Never redraw the monkey.
- The sticker skin and the Bungee headline type are allowed **only** for the show, Shorts and event covers.

## 6. Colour variants

| Variant                   | W / square                                                | "opee.io" | Dot    | Background                                  | Use                                                                                                                   |
| ------------------------- | --------------------------------------------------------- | --------- | ------ | ------------------------------------------- | --------------------------------------------------------------------------------------------------------------------- |
| **color-light (default)** | yellow square, ink W                                      | ink       | purple | white / `#f3f4f6`                           | Site light mode, docs light, email (always), decks                                                                    |
| **color-dark**            | square off, yellow W                                      | white     | yellow | ink `#111827` / night `#0b0f19` / `#1b1b1d` | Site dark mode, docs, video                                                                                           |
| **on-purple**             | yellow square, ink W                                      | white     | yellow | purple `#7030a0`                            | Brand surfaces, LinkedIn cover, slides                                                                                |
| **on-yellow**             | ink square, yellow W                                      | ink       | purple | yellow `#ffcc00`                            | Avatars, merch, end cards, deck covers                                                                                |
| **mono-ink**              | ink square, W knocked out (L1); ink W (L4)                | ink       | ink    | any light                                   | Print, stamps, navy and white templates                                                                               |
| **mono-black**            | black `#000` square, W knocked out (L1, L3); black W (L4) | black     | black  | white or uncoated paper                     | One-colour print only: screen printing, stamps, laser engraving, fax and B/W office printers. On screen, use mono-ink |
| **mono-white**            | white square, W knocked out (L1); white W (L4)            | white     | white  | any dark, or a photo with an overlay        | Video overlays, dark partner pages                                                                                    |

**Contrast (WCAG 2.x):**

| Pair                                        | Ratio           | Verdict                                                                                         |
| ------------------------------------------- | --------------- | ----------------------------------------------------------------------------------------------- |
| ink `#111827` on yellow `#ffcc00`           | 11.73:1         | pass (AAA)                                                                                      |
| yellow on night `#0b0f19`                   | 12.67:1         | pass (AAA)                                                                                      |
| yellow on `#1b1b1d` (Docusaurus dark)       | 11.37:1         | pass (AAA)                                                                                      |
| ink on white                                | 17.74:1         | pass (AAA)                                                                                      |
| white on purple `#7030a0`                   | 8.02:1          | pass (AAA)                                                                                      |
| yellow on purple                            | 5.30:1          | pass (AA text, graphics)                                                                        |
| purple on white                             | 8.02:1          | pass (Commander tile, descriptor and dot on light)                                              |
| purple on yellow                            | 5.30:1          | pass (the dot on yellow)                                                                        |
| purple-300 `#b98ae0` on ink / night         | 6.57:1 / 7.09:1 | pass (Commander on dark)                                                                        |
| **yellow on white**                         | **1.51:1**      | **fail**: never yellow text or a yellow-only shape on white; the square is carried by the ink W |
| **purple on ink**                           | **2.21:1**      | **fail**: never a purple #7030a0 logo part on dark; use purple-300                              |
| **brand yellow vs verdict amber `#eab308`** | **1.27:1**      | **collision**: no yellow logo in the Commander status area                                      |

- Every logo element holds **3:1 against its background**, and the wordmark **4.5:1**.
- Never use other tints, gradients, shadows, glows or outlines. Cyan and indigo are not brand colours.

## 7. Clear space

- x = the height of the lowercase "o" in "opee.io".
- Keep **1x** on all sides of L1, L2, L4 and L5, and **0.5x** around L3.
- Inside UI chrome (nav bars, the Commander pill), the bar's padding counts as the clear space.
- No text, edge, photo subject or other logo enters the clear-space box.
- The SVG viewBoxes are tight to the artwork, so clear space is added by the layout, never baked into the file.

## 8. Minimum sizes

| Lockup                  | Screen min                                                 | Print min | Notes                                                                                          |
| ----------------------- | ---------------------------------------------------------- | --------- | ---------------------------------------------------------------------------------------------- |
| L1 primary              | 80 px wide (about 17 px tall)                              | 20 mm     | Below 24 px tall, use L4                                                                       |
| L2 stacked              | 96 px tall                                                 | 25 mm     | The monkey needs at least 48 px                                                                |
| L3 symbol (full)        | 24 px                                                      | 6 mm      |                                                                                                |
| L3 symbol (favicon cut) | 16 px                                                      | n/a       | Separate hand-tuned drawing, `favicon-16.png`                                                  |
| L5 sub-brand            | 120 px wide                                                | 30 mm     | Descriptor cap height at least 6 px, so the lockup at least 41 px tall (at 40 px it is 5.9 px) |
| Mascot (tier 2)         | 36 px (the email sign-off); 24 px only for comment avatars | 12 mm     | The original art has fine linework; below 24 px, use L3                                        |

## 9. Icons: favicon, app, PWA and avatars

### 9.1 Web icon set (per site)

wopee.io and docs.wopee.io use [icons-wopee/](favicons/wopee/) (yellow tile). cmd.wopee.io uses [icons-commander/](favicons/commander/) (purple tile). Side by side, the tabs tell the products apart.

| File                                             | Size                | Content                                                                                                                    |
| ------------------------------------------------ | ------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| `favicon.ico`                                    | 16 + 32 + 48 layers | PNG-compressed layers; the 16 layer is the hand-tuned cut, not a resample                                                  |
| `favicon-16.png`                                 | 16×16               | Hand-tuned pixel cut: 4 px arms, the two 1 px counters either side of the hump, the foot notch and taper, 50 % edge pixels |
| `favicon-32.png`, `favicon-48.png`               | 32, 48              | The small-size cut (W at 70 % of the tile), the same drawing as `icon.svg`                                                 |
| `apple-touch-icon.png`                           | 180×180             | Opaque full-bleed tile, W at 50 %; iOS rounds the corners                                                                  |
| `icon-192.png`, `icon-512.png`                   | 192, 512            | The L3 symbol with transparent corners; manifest `"purpose": "any"`                                                        |
| `icon-maskable-192.png`, `icon-maskable-512.png` | 192, 512            | Full-bleed tile, W at 40 % inside the safe circle; manifest `"purpose": "maskable"`                                        |

```html
<link rel="icon" href="/favicon.ico" sizes="16x16 32x32 48x48" />
<link rel="icon" href="/icon.svg" type="image/svg+xml" />
<link rel="apple-touch-icon" href="/apple-touch-icon.png" />
<link rel="manifest" href="/manifest.webmanifest" />
```

```json
"icons": [
  { "src": "/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any" },
  { "src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any" },
  { "src": "/icon-maskable-192.png", "sizes": "192x192", "type": "image/png", "purpose": "maskable" },
  { "src": "/icon-maskable-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
]
```

The tiles are opaque, so no `prefers-color-scheme` flip is needed.

### 9.2 Avatars: two tiers, applied the same way everywhere

| Channel                                     | File                                                                                                                            | Content                                                          |
| ------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------- |
| YouTube @wopee                              | [`avatars/wopee-mascot-head-on-yellow-800.png`](avatars/wopee-mascot-head-on-yellow-800.png)                                    | **tier 2:** the original monkey on yellow, as on the 2023 avatar |
| LinkedIn company, X, Bluesky                | [`avatars/wopee-mascot-head-on-yellow-400.png`](avatars/wopee-mascot-head-on-yellow-400.png)                                    | tier 2, the same drawing                                         |
| Email sign-off                              | [`avatars/wopee-mascot-head-on-yellow-72.png`](avatars/wopee-mascot-head-on-yellow-72.png) (shown at 36 px)                     | tier 2                                                           |
| GitHub `Wopee-io` and `autonomous-testing`  | [`avatars/wopee-avatar-tile-500.png`](avatars/wopee-avatar-tile-500.png)                                                        | **tier 1:** the yellow W tile, both orgs identical               |
| npm `wopee-mcp`, MCP registry `icons`       | [`avatars/wopee-avatar-tile-mcp-512.png`](avatars/wopee-avatar-tile-mcp-512.png) + `svg/wopee-symbol-mcp-color-light.svg`       | tier 1: the MCP ink tile                                         |
| Okta / Entra SSO tile, trust page, invoices | [`avatars/wopee-avatar-tile-512.png`](avatars/wopee-avatar-tile-512.png) (Commander app: `wopee-avatar-tile-commander-512.png`) | tier 1                                                           |

- Avatar files are full-bleed squares; the platform crops them to a circle or a rounded square. The W tiles keep the W inside the inner 80 % circle. The mascot avatar fills the height as the original 2023 avatar did: in a circle crop the cap top and the headphones touch the rim, and the face stays inside.

### 9.3 Covers and banners

- **LinkedIn cover (1128×191):** L1 on-purple.
- **YouTube banner (2560×1440, safe area 1546×423):** L1 on-yellow.
- **Email header:** 600 px wide, light only, L1 color-light PNG @2x shown at 28 px high.
- The logo is never larger than ⅓ of the safe width.

## 10. Mascot (the monkey) vs the logo

|            | Logo (W + "opee.io")                                               | Mascot (monkey with cap and sunglasses)                                                                                                                |
| ---------- | ------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Tier       | 1: corporate                                                       | 2: character                                                                                                                                           |
| Role       | Signature, ownership, navigation                                   | Personality: avatar, sign-off, reactions, storytelling                                                                                                 |
| Where      | Headers, favicons, legal, invoices, SSO, registries, partner pages | Social avatars, end cards, carousel and deck covers, the email sign-off, stickers, 404s, empty states                                                  |
| Never      | Replaced by the mascot                                             | Used in place of the logo, put in the corporate lockup or a customer logo row, put on a customer-quote card, or used as the narrator                   |
| Change     | Fixed artwork                                                      | May pose and emote (🐒 🐵 🙈 🙉 🙊), but its model sheet stays fixed                                                                                   |
| Background | Section 6 variants                                                 | **White or yellow grounds, or the yellow disc badge**; on dark and purple grounds, the disc only (its black parts and the purple cap vanish otherwise) |

- **One drawing: the original.** The mascot is the original 2023 Wopee.io monkey (the yellow-ground avatar on GitHub and LinkedIn). It is never redrawn, simplified or retraced. The masters only crop, scale and place it.
  - Files: [`wopee-mascot-head-color-light.svg`](mascot/wopee-mascot-head-color-light.svg) (transparent, for white and yellow grounds), [`wopee-mascot-head-color-dark.svg`](mascot/wopee-mascot-head-color-dark.svg) (the disc badge: the monkey on a yellow disc, headphones cut by the rim, for dark and purple grounds), [`wopee-mascot-head-on-yellow.svg`](mascot/wopee-mascot-head-on-yellow.svg) (the avatar square).
- **Cap colours:** as drawn in the original: a purple cap with a yellow W, yellow-rimmed sunglasses and purple headphones. No cap recolouring for any ground; where the purple cap would vanish (purple and dark grounds), use the disc badge. The yellow-cap 2023 variant is not part of the masters; the pink, teal, blue and navy colourways are retired.
- **Link to the logo:** the cap carries the Bungee W, the same glyph as the logo.
- **Icon rule:** the Wopee.io icon is always a monkey, **never a microscope** 🔬.
- **Together:** the mascot and the logo appear together only in L2, end cards, deck covers and merch, with the logo as the smaller signature.

## 11. Backgrounds and photos

- **Photos:** use mono-white on a 40 % ink overlay, or L1 on a solid color-light or color-dark plate.
- **Brand gradients** (purple to ink): place the logo on the purple end, in the on-purple variant.
- **Yellow grounds:** use on-yellow, the ink square.
- **Co-branded decks** on yellow or navy templates:
  - use color-dark on an ink plate, or mono-ink or mono-white;
  - put the client logo in a white chip.
- **No hazard look:** no diagonal stripes, chevrons or tape patterns near the logo.

## 12. Misuse

1. "W Wopee.io": the W or its square before the full word, or stacked above it.
2. Stretching, squashing, skewing or rotating it (the Build & Break sticker tilt applies to the show skin only).
3. Recolouring it outside section 6, for example a purple #7030a0 logo on dark, a yellow W in the Commander status area, or a yellow wordmark on white.
4. Adding shadows, glows, gradients, outlines or 3D.
5. Rearranging it: a changed gap, the descriptor moved, the square kept on dark grounds, or a second accent colour.
6. Retyping the wordmark as live text or in another font, or a W from any font other than Bungee.
7. Using the old marks: the black or white W PNG, the purple masked W, the Arial Black email W, the potrace docs SVG, or the stair-step favicon polygon.
8. Putting the mascot in place of the logo, or the mascot on dark without a yellow disc.
9. Inventing a product symbol (a new icon for Commander or MCP) instead of a tile colour.
10. Placing it on a busy photo or a low-contrast background.
11. Cropping the W or its square.
12. Breaking the clear space.
13. Writing the name in caps or without ".io" in the corporate lockup.
14. Using a microscope or any non-monkey icon for Wopee.io.
15. Locking a tagline into the logo ("Autonomous Testing Bots", "AI Testing Agent for Apps").
16. Adding red to the brand or the Build & Break skin.

## 13. Files and naming

Pattern: `wopee-{lockup}[-{product}]-{variant}[-{size}].{ext}`, with `@2x` before the extension for retina PNGs.

- lockup: `logo-horizontal` · `logo-stacked` · `symbol` · `wordmark` · `favicon` · `avatar-tile` · `mascot-head` · `sticker` · `colours`
- product: `commander` · `mcp` · `bb`
- variant: `color-light` · `color-dark` · `on-purple` · `on-yellow` · `mono-ink` · `mono-black` · `mono-white`
- Icon sets inside `icons-wopee/` and `icons-commander/` keep the filenames the browsers and manifests expect (`favicon.ico`, `apple-touch-icon.png`, `icon-512.png`).

| Format                                                                                                                                                | When                                                                                       |
| ----------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| SVG: outlined, no fonts, no raster, no metadata, `viewBox` tight to the artwork, `role="img"` + `<title>`, passes `xmllint`; the symbol is about 1 KB | Web, master                                                                                |
| PNG @1x/@2x, transparent                                                                                                                              | Email (Brevo), Slidev, Office, chat tools                                                  |
| ICO / PNG icon set                                                                                                                                    | Section 9.1                                                                                |
| PDF (vector)                                                                                                                                          | Print and agencies: export from the SVG when needed                                        |
| GIF / MP4 / animated SVG                                                                                                                              | Motion sting only; honours `prefers-reduced-motion`; the static fallback is the rest frame |

- **Colour spaces:** sRGB hex for screen. Print CMYK and Pantone values come after a print proof.

### 13.1 Brand kit 2026

`wopee-brand-kit-2026.zip` is the public download for partners, press and agencies, from [wopee.io/brand](https://wopee.io/brand/):

| Folder in the zip                        | Contents                                                                                                       |
| ---------------------------------------- | -------------------------------------------------------------------------------------------------------------- |
| `logos/svg/`, `logos/png/`               | L1, L4 and L3 in every variant (mono-black included), L2, L5 Commander and MCP; PNG @2x and the 512 px symbols |
| `favicons/wopee/`, `favicons/commander/` | Section 9.1, plus `icon.svg`                                                                                   |
| `avatars/`                               | The mascot avatar (800, 400, 72) and the W tiles                                                               |
| `mascot/`                                | The original monkey and its disc badge (SVG, PNG @2x)                                                          |
| `wopee-colours.png`, `wopee-colours.svg` | The colour sheet                                                                                               |
| `wopee-logo-guidelines.md`               | This guideline                                                                                                 |
